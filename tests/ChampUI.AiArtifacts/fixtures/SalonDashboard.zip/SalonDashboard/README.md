# Lumière Salon — ChampUI Dashboard

A bilingual .NET 10 Blazor Interactive Server salon reception dashboard generated from the **published** SadeemSystems.ChampUI.Templates 0.1.3 Dashboard Starter, consuming the official **ChampUI 0.3.3** NuGet package. No local imitation of ChampUI components.

## Run
Requires .NET 10 SDK.
```sh
dotnet restore --source https://api.nuget.org/v3/index.json
dotnet build -c Release --no-restore
dotnet run
```
Open the URL printed in the terminal.

## Features
- Overview and revenue KPIs: today's completed appointment revenue, current month revenue, seven-day revenue trend, customer/staff counts and appointment statuses.
- Customer and employee directories: searchable, sortable tables; add and edit records.
- Services: add/edit description, KWD price and duration.
- Appointments: select customer, employee, service, Kuwait date/time; reject overlapping customer or employee bookings; complete or cancel scheduled visits.
- Settings: English / Arabic RTL, light / dark mode, workspace name; responsive navigation provided by the official starter.

The service layer uses decimal for prices and snapshots the service price and duration at booking time. Revenue is a **completed-service value**, not verified cash receipts. Seed records are fictional; all mutations are circuit-scoped and disappear on reload. This is a dashboard prototype, not a production accounting or multi-tenant system. Durable storage, authentication, role-based access, payments, audit history and full browser accessibility testing remain future work. User-entered names and service descriptions are not translated automatically.

## Validation
- .NET SDK 10.0.100, official template 0.1.3 and ChampUI package 0.3.3.
- Release build: 0 errors, 0 warnings.
- HTTP smoke tests: all seven routes return 200.
- Business checks: 11/11 pass (create/update customer, invalid employee, service create and negative price, appointment creation and overlap, scheduled excluded, service edit, completed price snapshot and protected completed status).
- Interactive browser QA not completed: Chromium executable unavailable and Playwright download returned HTTP 403. RTL/theme/mobile layout follow the starter but require browser verification.

## Provenance
Official template: https://www.nuget.org/packages/SadeemSystems.ChampUI.Templates/0.1.3
Official library: https://www.nuget.org/packages/ChampUI/0.3.3
API catalog: https://github.com/aqeelhashem2-maker/ChampUI/tree/3d4c98bfbc12b0d23dbd1266ecaefccd3a39e9ff/docs/ai
