namespace SalonDashboard.Services;

public enum BookingStatus { Scheduled, Completed, Cancelled }
public record SalonPerson(int Id, string Name, string Detail);
public record SalonService(int Id, string Name, decimal Price, int Minutes);
public record Booking(int Id, int CustomerId, int EmployeeId, int ServiceId, DateTime Start, decimal Price, int Minutes, BookingStatus Status);

public sealed class SalonStore
{
    public DateTime Today => DateTime.UtcNow.AddHours(3).Date;
    public List<SalonPerson> Customers { get; } = [new(1,"Sara Al Ali","5550 0101"),new(2,"Noor Ahmad","5550 0102"),new(3,"Mariam Hassan","5550 0103"),new(4,"Huda Salem","5550 0104")];
    public List<SalonPerson> Employees { get; } = [new(1,"Layla","Hair stylist"),new(2,"Amal","Nail specialist"),new(3,"Rania","Beauty specialist")];
    public List<SalonService> Services { get; } = [new(1,"Hair styling",18m,45),new(2,"Manicure",12m,30),new(3,"Facial treatment",25m,60),new(4,"Hair coloring",45m,90)];
    public List<Booking> Bookings { get; }
    public SalonStore()
    {
        Bookings = Enumerable.Range(1,12).Select(i => {
            var service = Services[(i-1)%4];
            return new Booking(i,(i-1)%4+1,(i-1)%3+1,service.Id,Today.AddDays(-i%7).AddHours(9+i%8),service.Price,service.Minutes,i%4==0?BookingStatus.Cancelled:BookingStatus.Completed);
        }).Concat([new Booking(13,1,1,1,Today.AddHours(10),18,45,BookingStatus.Scheduled),new Booking(14,2,2,2,Today.AddHours(11),12,30,BookingStatus.Scheduled),new Booking(15,3,3,3,Today.AddHours(14),25,60,BookingStatus.Scheduled)]).ToList();
    }
    public string Customer(int id) => Customers.FirstOrDefault(x=>x.Id==id)?.Name ?? "—";
    public string Employee(int id) => Employees.FirstOrDefault(x=>x.Id==id)?.Name ?? "—";
    public string Service(int id) => Services.FirstOrDefault(x=>x.Id==id)?.Name ?? "—";
    public decimal Revenue(DateTime from, DateTime to) => Bookings.Where(x=>x.Status==BookingStatus.Completed && x.Start>=from && x.Start<to).Sum(x=>x.Price);
    public bool SavePerson(bool employee,int id,string name,string detail)
    {
        if(string.IsNullOrWhiteSpace(name)||string.IsNullOrWhiteSpace(detail)||name.Length>100||detail.Length>100)return false;
        var list=employee?Employees:Customers;
        if(id!=0 && !list.Any(x=>x.Id==id))return false;
        var item=new SalonPerson(id==0?list.Select(x=>x.Id).DefaultIfEmpty().Max()+1:id,name.Trim(),detail.Trim());
        list.RemoveAll(x=>x.Id==item.Id);list.Add(item);return true;
    }
    public bool SaveService(int id,string name,decimal price,int minutes)
    {
        if(string.IsNullOrWhiteSpace(name)||name.Length>100||price<0||price>10000||minutes<5||minutes>480)return false;
        if(id!=0&&!Services.Any(x=>x.Id==id))return false;
        var item=new SalonService(id==0?Services.Select(x=>x.Id).DefaultIfEmpty().Max()+1:id,name.Trim(),price,minutes);
        Services.RemoveAll(x=>x.Id==item.Id);Services.Add(item);return true;
    }
    public bool AddBooking(int customer,int employee,int service,DateTime start)
    {
        var s=Services.FirstOrDefault(x=>x.Id==service);
        if(s is null||!Customers.Any(x=>x.Id==customer)||!Employees.Any(x=>x.Id==employee)||start<Today||start>Today.AddYears(1))return false;
        if(Bookings.Any(x=>x.Status!=BookingStatus.Cancelled&&(x.EmployeeId==employee||x.CustomerId==customer)&&x.Start<start.AddMinutes(s.Minutes)&&start<x.Start.AddMinutes(x.Minutes)))return false;
        Bookings.Add(new(Bookings.Select(x=>x.Id).DefaultIfEmpty().Max()+1,customer,employee,service,start,s.Price,s.Minutes,BookingStatus.Scheduled));return true;
    }
    public void SetStatus(int id,BookingStatus state)
    {
        var i=Bookings.FindIndex(x=>x.Id==id&&x.Status==BookingStatus.Scheduled);
        if(i>=0&&state!=BookingStatus.Scheduled)Bookings[i]=Bookings[i] with {Status=state};
    }
}
